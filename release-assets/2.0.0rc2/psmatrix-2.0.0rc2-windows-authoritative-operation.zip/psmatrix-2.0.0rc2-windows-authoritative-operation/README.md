# PSMatrix authoritative Windows Production GA operation

This package is ready to run on a protected self-hosted Hyper-V controller. It does not contain a private key and it does not claim that Windows PowerShell 4.0/5.0/5.1 campaigns were executed.

## Current state

- implementation and local contract tests: PASS;
- release-bound predicate v2 preflight: PASS;
- source/wheel/Windows package reproducibility and signatures: PASS;
- real authoritative Windows campaign: NOT EXECUTED;
- Production GA Windows gate: INCOMPLETE.

## Run

1. Install the GitHub workflow on a repository containing this exact commit.
2. Configure the protected `production-ga-windows-lab` environment.
3. Prepare `PSMATRIX_WINDOWS_GA_ROOT` using `operator/windows-ga-layout.template.json`.
4. Add the three protected key secrets documented in `operator/PRODUCTION_GA_WINDOWS.md`.
5. Start `production-ga-authoritative-windows` with the exact final release commit.
6. Keep `provision=false` for existing reviewed golden images, or explicitly approve `provision=true` to rebuild them.
7. Verify and copy `windows-authoritative.dsse.json` into the final GA evidence directory.

The files under `release-preflight/` use an ephemeral preflight authority and are not Production GA evidence.
