# PSMatrix independent security-review handoff

## Current state

- Candidate commit: `f606c96310c8ba9fa2f7a11c6cadf58dd0791df9`
- Full regression: `234/234 PASS`
- Real runtime used: `powershell-7.6.4-linux-x64`
- Review status: `PRE_REVIEW_READY`
- Production GA security-review gate: `INCOMPLETE`

No independent reviewer has completed or signed this review. No reviewer private
key is included in this package.

## Independence requirements

The reviewer must be operationally independent from the release owner, control
the Ed25519 signing private key, declare no conflict of interest, and review all
nine mandatory sections using all four required methodologies.

The release owner must not generate, hold, transmit, or escrow the reviewer
private key.

## Pre-review

Open `psmatrix-2.0.0rc2-independent-security-pre-review.zip` and review the
candidate source, architecture/security documents, test evidence, and threat
boundaries. The included report template is bound to the current candidate.

## Final GA review

The final proof cannot use the current candidate manifest. After the signed core
`psmatrix-2.0.0-release.json` and its matching source ZIP exist, rebuild the
review packet against those exact artifacts. The reviewer must then update the
report hashes and sign it:

```bash
psmatrix ga review-packet \
  --root /path/to/exact-reviewed-checkout \
  --source-archive psmatrix-2.0.0-source.zip \
  --release-manifest psmatrix-2.0.0-release.json \
  --output psmatrix-2.0.0-independent-security-review.zip

psmatrix ga review-finalize \
  --report security-review-report.json \
  --source-archive psmatrix-2.0.0-source.zip \
  --release-manifest psmatrix-2.0.0-release.json \
  --private-key reviewer.private.pem \
  --public-key reviewer.public.pem \
  --result-output security-review-result.json \
  --attestation-output security-review.dsse.json

psmatrix ga proof-verify \
  --type security-review \
  --attestation security-review.dsse.json \
  --public-key reviewer.public.pem
```

The GA evaluator cross-checks the review against:

- the exact `git_commit` in the final validation summary;
- the SHA-256 of the signed final release manifest;
- a source ZIP digest listed in the signed final release.

A proof for an older candidate, a different source ZIP, or a different release
manifest fails the GA gate even when its DSSE signature is valid.
